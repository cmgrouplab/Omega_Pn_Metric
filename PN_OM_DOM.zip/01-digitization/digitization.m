clc;
clear;
close all;
PicNum=5;
fileName='';
Reference=18; % Setting the reference image. 
%For example, if Reference=18, it means that we set 18'th image as the reference. 
for a = 1+Reference-1:PicNum+Reference-1  % Used for different reference image. 
    
if (0<=a)&&(a<10)
B='000';
C = [ B num2str(a)];
fileName = [ 'image.' C '.png']; % If your input name format is different, you can change the format here.
end 

if (10<=a)&&(a<100)
B='00';
C = [ B num2str(a)];
fileName = [ 'image.' C '.png'];
end   
    
if (100<=a)&&(a<1000)
B='0';
C = [ B num2str(a)];
fileName = [ 'image.' C '.png'];
end 

I=imread(fileName);
subplot(1,3,1);
imshow(I);

IBW=rgb2gray(I);
subplot(1,3,2);
imshow(IBW);


OutPutName = [num2str(a-Reference+1) 'Mconfig'  '.txt']; % Used for different reference image. 

fid=fopen(OutPutName,'w');
sum=0;

%1 is white and 0 is black in MATLAB
%1 is white and 0 is black in MATLAB
%1 is white and 0 is black in MATLAB
%1 is white and 0 is black in MATLAB

for i=1:size(IBW,1)
    for j=1:size(IBW,2)
    if IBW(i,j)>230       % One can try to adjust this threshold value to segment the image.
   IBW(i,j)=0;
    else     
   IBW(i,j)=1;
    end
    end
end

%0 is white and 1 is black in C++
%0 is white and 1 is black in C++
%0 is white and 1 is black in C++
%0 is white and 1 is black in C++

for i=1:size(IBW,1)
    for j=1:size(IBW,2)
        
     if i>=42 && i<=242 && j>=136 && j<=336    % You can set specific scope to analyze the image.     
                                               % Remember that "This scope must be square"
                                               % The scope of "i>=42 && i<=242 && j>=136 && j<=336" is square here. 
    if IBW(i,j)==1       
    sum=sum+1;
    end
    
     end                                       % You can set specific scope to analyze the image.   
    
    
    end
end

fprintf(fid, '%10.0f\n',sum);

for i=1:size(IBW,1)
    for j=1:size(IBW,2)
        
       if i>=42 && i<=242 && j>=136 && j<=336   % You can set specific scope to analyze the image.        
        
    if IBW(i,j)==1       
    fprintf(fid,'%1.0f %1.0f\n', i-1, j-1);
   % sum=sum+1;
    end
    
      end                                       % You can set specific scope to analyze the image. 
    
    end
end


IBWP=IBW;
for i=1:size(IBWP,1)
    for j=1:size(IBWP,2)
    if IBWP(i,j)==1       
   IBWP(i,j)=0;
  
    else     
   IBWP(i,j)=255;
   
    end
    end
end
subplot(1,3,3);
imshow(IBWP);


end