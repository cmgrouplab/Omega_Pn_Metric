

#include <stdio.h>  //C library to perform Input/Output operations  fopen
#include <stdlib.h> //C Standard General Utilities Library
#include <math.h>
#include <iostream>
#include <time.h>
#include <string>
#include <fstream>

using namespace std;

#define MAXX 200 // **The area of interest. this has to be an even number !!! since the MAX value of Nt = MAXX/2  

#define Nt 100 // The desired distance to solve the Pn. Pn(x1.x2)=s2(r). Nt=1/2 because of the boundary condition.
#define PI acos(-1)
#define PicNum 5 // The number of image(s)

int NP; // The total # of the black pixels(i.e. inclusion).
double f1;//volume fraction of the black pixels(i.e. inclusion)
double f2;


int pix_position[MAXX]; //The position of black pixels 
int pix_counter; //The number of pixel on each line/column/height...


int config[MAXX][MAXX];   // The pixels' location within the whole area.

int lineS2[MAXX][Nt];     //Default value of every element of lineS2 is 0. If 2 selected elements are black pixels, its value will be 1.
int columeS2[MAXX][Nt];   //


int N2V[MAXX][Nt];        //2 D array  N2 vertical
int N2H[MAXX][Nt];        //2 D array  N2 horizental

double SQ[Nt]; // Used to store the P4function
double TriVer[Nt];// Used to store the P3V function
double TriHor[Nt];// Used to store the P3H function
double HexaVer[Nt];// Used to store the P6V function
double HexaHor[Nt];// Used to store the P6He function
double Octagon[Nt];// Used to store the P8 function
int Nside=100;
double Arbi[Nt];
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Parameter for Omega Function
//int round=1;
void inputfile(string aa, string bb);
void TransferData(string Pntxt);
void OMEGACALCULATION(float*,float*);
void FinilizedCalculation(string AA,string AAtxt);

float O2[Nt] [PicNum];
float O3[Nt] [PicNum];
float O4[Nt] [PicNum];
float O6[Nt] [PicNum];
float O8[Nt] [PicNum];

float matrix[Nt][PicNum];
float Calculation0[Nt][PicNum];
float Calculation[PicNum];
float ResultO2[PicNum-1];
float ResultO3[PicNum-1];
float ResultO4[PicNum-1];
float ResultO6[PicNum-1];
float ResultO8[PicNum-1];


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Functions for Pn Function


void sampleS2line(int index1)
{
	
  for(int r=0; r<Nt; r++)  // Initilize lineS2 for each column 
    {
      lineS2[index1][r] = 0; 
    }


  //Serach the line for pixel positions  
  pix_counter = 0;

  for(int i=0; i<MAXX; i++)
    {
      if(config[i][index1] == 1)    
	   {
	  pix_position[pix_counter] = i;  //It means that this point is inclusion .
	  pix_counter++;
	   }
    }

  //Now get the distance between all pixels on the line...
  int temp_dist;

  for(int i=0; i<pix_counter; i++)
    for(int j=0; j<=i; j++)
      {
	temp_dist = abs(pix_position[i]-pix_position[j]);

	if(temp_dist>=MAXX/2) temp_dist = MAXX-temp_dist;  

	lineS2[index1][temp_dist]++;  //   If 2 points exist, count 1.
      }

}



void sampleS2colume(int index1)
{

  for(int r=0; r<Nt; r++)
    {
      columeS2[index1][r] = 0;
    }

  //Serach the line for pixel's position
  pix_counter = 0;

  for(int i=0; i<MAXX; i++)
    {
      if(config[index1][i]==1)    
	{
	  pix_position[pix_counter] = i;
	  pix_counter++;
	}
    }

  //Now get the distance between all pixels on the line...
  int temp_dist;

  for(int i=0; i<pix_counter; i++)
    for(int j=0; j<=i; j++)
      {
	temp_dist = abs(pix_position[i]-pix_position[j]);

	if(temp_dist>=MAXX/2) temp_dist = MAXX-temp_dist;

	columeS2[index1][temp_dist]++;

      }

}




void sample_horizontal(int lindex) // Used for calculating lineal-path function for each row. The max value of lindex here is Maxx.
{
  for(int r=0; r<Nt; r++)
    N2H[lindex][r] = 0;  //N2H[maxx][Nt]=N2H[3][10] means that each Nt=10 of 3rd row is stored in this matrix. 

  int ener[MAXX];     // To indicate if the selected space is occupied by black Pix and how many black pixs are its neighbor.
  int flag_empty = 0;//The # of the black PIX

  for(int i=0; i<MAXX; i++)
    {
      if(config[lindex][i]==0) ener[i]=-1; //  if selected space is not occupied by black pix.......its value =-1
      else
	{
	  int en = 0;  // How many neighbors does the selected black pix has?
	  int neb1 = i - 1;  // ned1 and neb2 just used to determine the range of the selected black pix 
	  if(neb1<0) neb1 = neb1 + MAXX;
	  if(config[lindex][neb1]==1) en++;
	  int neb2 = i+1;
	  if(neb2>=MAXX) neb2 = neb2 - MAXX;  
	  if(config[lindex][neb2]==1) en++;

	  ener[i] = en;  // ener[Maxx] means the status of each elemnt. -1 means nothing. 0 means single black pix . 1 means that 2 ponits are connected. 2 means that 3 points are connected.
	  flag_empty ++;  // the # of the black PIX
	}
    }

  int position[MAXX]; // Used for calculating the distance.
  for(int i=0; i<MAXX; i++)
    {
      position[i] = -1;  //Initializing the position array=-1
    }

  int ctp = 0;  // ctp should be the acrony of connected point.
  for(int i=0; i<MAXX; i++)
    {
      if(ener[i]==1) 
	{
	  position[ctp] = i;  // Position of 2 connected black pixs
	  ctp++;
	}
      else if(ener[i]==0) //This counts for the individula pixels...(single existing pix)
	{
	  N2H[lindex][0]++;  // Because it does not have any connection with other , the connection length is 0.
	}
    }
  
  //when the cord is at the bd
  if(config[lindex][0]==1&&config[lindex][MAXX-1]==1)
    {
      if(ctp>2)  
	{
	  for(int i=1; i<ctp-1; i=i+2)
	    {
	      int len = position[i+1]-position[i]+1; 
	      for(int r=0; r<=len; r++)
		{
		  if(r<Nt) N2H[lindex][r] = N2H[lindex][r]+(len-r);   // Calculate the r for the middle sections which are not connected with BC part.
		}
	    }

	  int len = (position[0]+1)+(MAXX - position[ctp-1]);   // Calculate the BC part.
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2H[lindex][r] = N2H[lindex][r]+(len-r);  
	    }
	}
      else if(ctp ==2) // only two single black PIX at each end.
	{
	  int len = (position[0]+1)+(MAXX - position[ctp-1]);   //   �� �� �� �� �� �� �� �� �� ��   or �� �� �� �� �� �� �� ��
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2H[lindex][r] = N2H[lindex][r]+(len-r);  
	    }
	}
      else if(ctp == 0 & flag_empty != 0) // ALL black points     �� �� �� �� �� �� �� �� ��
	{
	  int len = MAXX;
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2H[lindex][r] = N2H[lindex][r]+(len-r);  
	    }
	}

    }

  //When the cord is not at the bd
  else
    {
      for(int i=0; i<ctp; i=i+2)
	{
	  int len = position[i+1]-position[i]+1;  //  The distance between 2 black pix. 
	  for(int r= 0; r<=len; r++)
	    {
	      if(r<Nt) N2H[lindex][r] = N2H[lindex][r]+(len-r);  
	    }
	}
    }



}

void sample_vertical(int cindex)  // Used for calculating lineal-path function
{
 for(int r=0; r<Nt; r++)
    N2V[cindex][r] = 0;

  int ener[MAXX];
  int flag_empty = 0;
  for(int i=0; i<MAXX; i++)
    {
      if(config[i][cindex]==0) ener[i]=-1;
      else
	{
	  int en = 0;
	  int neb1 = i - 1;
	  if(neb1<0) neb1 = neb1 + MAXX;
	  if(config[neb1][cindex]==1) en++;
	  int neb2 = i+1;
	  if(neb2>=MAXX) neb2 = neb2 - MAXX;
	  if(config[neb2][cindex]==1) en++;

	  ener[i] = en;
	  flag_empty++;
	}
    }

  int position[MAXX];
  for(int i=0; i<MAXX; i++)
    {
      position[i] = -1;
    }

  int ctp = 0;
  for(int i=0; i<MAXX; i++)
    {
      if(ener[i]==1)
	{
	  position[ctp] = i;
	  ctp++;
	}
      else if(ener[i]==0) //It's counted for the individula pixels...
	{
	  N2V[cindex][0]++;
	}
    }

  if(config[0][cindex]==1&&config[MAXX-1][cindex]==1)//When the cord is at the bd
    {
      if(ctp>2)
	{
	  for(int i=1; i<ctp-1; i=i+2)
	    {
	      int len = position[i+1]-position[i]+1;
	      for(int r=0; r<=len; r++)
		{
		  if(r<Nt) N2V[cindex][r] = N2V[cindex][r]+(len-r);
		}
	    }

	  int len = (position[0]+1) + (MAXX - position[ctp-1]);
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2V[cindex][r] = N2V[cindex][r]+(len-r);
	    }
	}
      else if(ctp ==2)
	{
	  int len = (position[0]+1)+(MAXX - position[ctp-1]);
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2V[cindex][r] = N2V[cindex][r]+(len-r);
	    }
	}
      else if(ctp == 0 & flag_empty != 0)
	{
	  int len = MAXX;
	  for(int r=0; r<=len; r++)
	    {
	      if(r<Nt) N2V[cindex][r] = N2V[cindex][r]+(len-r);
	    }
	}

    }
  else
    {
      for(int i=0; i<ctp; i=i+2)
	{
	  int len = position[i+1]-position[i]+1;
	  for(int r= 0; r<=len; r++)
	    {
	      if(r<Nt) N2V[cindex][r] = N2V[cindex][r]+(len-r);
	    }
	}
    }



}

void squrefunction() //Sqindex=Maxx
{
	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different Square Size  
		
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			if(config[r][c]==1){ 
			
			int xx=c+R;
			if(xx>MAXX-1)
			xx=xx-MAXX;
			
			int yy=r+R;
			if(yy>MAXX-1)
			yy=yy-MAXX;
				
			if (config[r][xx]==1 && config[yy][c]==1 && config[yy][xx]==1){ //Confirm that if each square element is black or not
				
			SQ[R]++;
				
			    }
			 
			  }
		
			}		
		}
		
	}
	
  }
}

void TriangleVer() 
{
	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different Square Size  
		
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			// According the the value of R (ODD or EVEN) to select different Triangle
			// Sampling--> R is Even 
			   if(config[r][c]==1){       //  (r , c)                                ;   (r,c)                     
			      if((R+1)%2){            //                                         ;                             
			      int yy;                 //                 (r+R/2,c+sqrt(3)*(R/2)) ;                             (gg,yy)
			                              //                                         ;                              
		                                  //  (r+R,c)                                ;   (xx,c)
			
			
			      yy=c+ceil((float)R/2*sqrt(3));  
			      if(yy>MAXX-1)
			      yy=yy-MAXX;  
			
			      int gg=r+(R/2);                
			      if(gg>MAXX-1)
			      gg=gg-MAXX; 
			 
			      int xx=r+R;                     
			      if(xx>MAXX-1)
			      xx=xx-MAXX; 
			 
			         if (config[xx][c]==1 && config[gg][yy]==1){ //Confirm that if each square element is black or not	
			         TriVer[R]++;
			         }
			      }
			
			
		    // Sampling--> R is Odd
			      else{                                    //  (r,c)                                 ; (r,c)                   
			         int yy;                               //             (r+R/2  ,c+sqrt(3)*(R/2))  ;                       (gg  , yy)
			                                               //                                        ;
												           //             (r+R/2+1  ,c+sqrt(3)*(R/2));                       (ggSEC,yy)
			         yy=c+ceil((float)R/2*sqrt(3));        //  (r+R,c)                               ; (xx,c)        
			         if(yy>MAXX-1)
			         yy=yy-MAXX;
			
			         int gg=r+(R/2);  
			         if(gg>MAXX-1)
			         gg=gg-MAXX;
			
			         int ggSEC=gg+1;  
			         if(ggSEC>MAXX-1)
			         ggSEC=ggSEC-MAXX;
			 
			         int xx=r+R;      
			         if(xx>MAXX-1)
			         xx=xx-MAXX;
				
			         if (config[xx][c]==1){ //confirm that if each square element is black or not
			            
			            if (config[gg][yy]==1 || config[ggSEC][yy]==1 ){	
			            TriVer[R]++;
		                }
			         }	
			       } 
				
				
			   }  
    	    }		
	    }
    }
}
 
}

void TriangleHor() 
{

	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different Square Size  
		//int remanider;
		//remainder=(R%2);
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			// According the the value of R (ODD or EVEN) to select different Triangle
			// Sampling--> R is Even 
			if(config[r][c]==1){   //  (r,c)                    (r,c+R)      ;     (r,c)                    (r,xx)  
			if((R+1)%2){            //                                        ;
			int yy;                 //                                        ;
		                            //      (r+sqrt(3)*(R/2),c+(R/2))         ;                (yy,gg)
			
			
			
			yy=r+ceil((float)R/2*sqrt(3));  
			if(yy>MAXX-1)
			yy=yy-MAXX;  
			
			int gg=c+(R/2);                 
			if(gg>MAXX-1)
			gg=gg-MAXX; 
			 
			int xx=c+R;                     
			if(xx>MAXX-1)
			xx=xx-MAXX; 
			 	 
			if (config[r][xx]==1 && config[yy][gg]==1){ //confirm that if each square element is black or not	
			TriHor[R]++;
			  }
			}
		    // Sampling--> R is Odd
			else{                                 //  (r,c)                    (r,c+R)      ;     (r,c)                    (r,xx) 
			int yy;                               //                                        ;
			                                      //                                        ;
			yy=r+ceil((float)R/2*sqrt(3));        //      (r+sqrt(3)*(R/2),c+(R/2))         ;              (yy,gg)(yy,ggSEC)
			if(yy>MAXX-1)
			yy=yy-MAXX;
			
			int gg=c+(R/2);  
			if(gg>MAXX-1)
			gg=gg-MAXX;
			
			int ggSEC=gg+1;  
			if(ggSEC>MAXX-1)
			ggSEC=ggSEC-MAXX;
			
			int xx=c+R;
			if(xx>MAXX-1)
			xx=xx-MAXX;
				
			if (config[r][xx]==1){ //Confirm that if each square element is black or not
			
			if (config[yy][gg]==1 ||config[yy][ggSEC]==1 ){	
			TriHor[R]++;
		          }
			     }	
			    }  
			   }  
    	    }		
	    }
    }
}
 



}



void HexagonVer() 
{
	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different hexagon Size  
		
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			if(config[r][c]==1){ 
			
			
			float P2x=0;
			float P2y=0;
			float P3x=0;
			float P3y=0;
			float P4x=0;
			float P4y=0;
			float P5x=0;
			float P5y=0;
			float P6x=0;
			float P6y=0;
			
		    P2x=r+(sqrt(3)*0.5*R);
			P2y=c-(0.5*R);
			P3x=r+(sqrt(3)*0.5*R)+(sqrt(3)*0.5*R);
			P3y=c+(0.5*R)-(0.5*R);
			P4x=r+(sqrt(3)*0.5*R)+(sqrt(3)*0.5*R);
			P4y=c+(0.5*R)-(0.5*R)+R;
			P5x=r+(sqrt(3)*0.5*R);
			P5y=c+R+(0.5*R);
			P6x=r;
			P6y=c+R;
			
			P2x=ceil(P2x);
			P2y=ceil(P2y);
			P3x=ceil(P3x);
			P3y=ceil(P3y);
			P4x=ceil(P4x);
			P4y=ceil(P4y);
			P5x=ceil(P5x);
			P5y=ceil(P5y);
			P6x=ceil(P6x);
			P6y=ceil(P6y);
	
			
			if(P2x>MAXX-1)
			P2x=P2x-MAXX;
			if(P2y<0)
			P2y=P2y+MAXX;
			
			if(P3x>MAXX-1)
			P3x=P3x-MAXX;
			
			
			if(P4x>MAXX-1)
			P4x=P4x-MAXX;
			if(P4y>MAXX-1)
			P4y=P4y-MAXX;
			
			if(P5x>MAXX-1)
			P5x=P5x-MAXX;
			if(P5y>MAXX-1)
			P5y=P5y-MAXX;
			
		
			if(P6y>MAXX-1)
			P6y=P6y-MAXX;
			
		
				
			if (config[(int)P2x][(int)P2y]==1 && config[(int)P3x][(int)P3y]==1 && config[(int)P4x][(int)P4y]==1 && config[(int)P5x][(int)P5y]==1 && config[(int)P6x][(int)P6y]==1){ //confirm that if each square element is black or not
				
			HexaVer[R]++;
			      }
			  }

			}		
		}
		cout<<HexaVer[R]<<"***"<<endl;
	}
	
  }
}


void HexagonHor() 
{
	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different hexagon Size  
		
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			if(config[r][c]==1){ 
			
			
			float P2x=0;
			float P2y=0;
			float P3x=0;
			float P3y=0;
			float P4x=0;
			float P4y=0;
			float P5x=0;
			float P5y=0;
			float P6x=0;
			float P6y=0;
			
		    P2x=r+R;
			P2y=c;
			P3x=r+R+(0.5*R);
			P3y=c+(sqrt(3)*0.5*R);
			P4x=r+R;
			P4y=c+(sqrt(3)*0.5*R);
			P5x=r;
			P5y=c+(sqrt(3)*R);;
			P6x=r-(0.5*R);
			P6y=c+(sqrt(3)*0.5*R);
			
			P2x=ceil(P2x);
			P2y=ceil(P2y);
			P3x=ceil(P3x);
			P3y=ceil(P3y);
			P4x=ceil(P4x);
			P4y=ceil(P4y);
			P5x=ceil(P5x);
			P5y=ceil(P5y);
			P6x=ceil(P6x);
			P6y=ceil(P6y);
	
			
			if(P2x>MAXX-1)
			P2x=P2x-MAXX;
		
			
			if(P3x>MAXX-1)
			P3x=P3x-MAXX;
			if(P3y>MAXX-1)
			P3y=P3y-MAXX;
			
			if(P4x>MAXX-1)
			P4x=P4x-MAXX;
			if(P4y>MAXX-1)
			P4y=P4y-MAXX;
			
			
			if(P5y>MAXX-1)
			P5y=P5y-MAXX;
			
		
			
			if(P2x<0)
			P2x=P2x+MAXX;
		    if(P6y>MAXX-1)
			P6y=P6y-MAXX;
				
			if (config[(int)P2x][(int)P2y]==1 && config[(int)P3x][(int)P3y]==1 && config[(int)P4x][(int)P4y]==1 && config[(int)P5x][(int)P5y]==1 && config[(int)P6x][(int)P6y]==1){ //confirm that if each square element is black or not
				
			HexaHor[R]++;
			      }
			  }

			}		
		}
		cout<<HexaHor[R]<<"***"<<endl;
	}
	
  }
}








void Octa() 
{
	if(Nt<=MAXX/2){          //Reconfirm that Nt<=MAXX
	
	for (int R=0;R<Nt;R++){ // Run the different hexagon Size  
		
		for (int r=0;r<MAXX;r++){ // Run the config matrix from left to right and up to down 
			
			for (int c=0;c<MAXX;c++){
			
			if(config[r][c]==1){ 
			
			
			float P2x=0;
			float P2y=0;
			float P3x=0;
			float P3y=0;
			float P4x=0;
			float P4y=0;
			float P5x=0;
			float P5y=0;
			float P6x=0;
			float P6y=0;
			float P7x=0;
			float P7y=0;
			float P8x=0;
			float P8y=0;
			
		    P2x=r+(R/sqrt(2));
			P2y=c-(R/sqrt(2));
			P3x=r+(R/sqrt(2))+R;
			P3y=c-(R/sqrt(2));
			P4x=r+((2*R/sqrt(2))+R);
			P4y=c;
			P5x=r+((2*R/sqrt(2))+R);
			P5y=c+R;
			P6x=r+(R/sqrt(2))+R;
			P6y=c+R+(R/sqrt(2));
			P7x=r+(R/sqrt(2));
			P7y=c+R+(R/sqrt(2));
			P8x=r;
			P8y=c+R;
			
			P2x=ceil(P2x);
			P2y=ceil(P2y);
			P3x=ceil(P3x);
			P3y=ceil(P3y);
			P4x=ceil(P4x);
			P4y=ceil(P4y);
			P5x=ceil(P5x);
			P5y=ceil(P5y);
			P6x=ceil(P6x);
			P6y=ceil(P6y);
			P7x=ceil(P7x);
			P7y=ceil(P7y);
			P8x=ceil(P8x);
			P8y=ceil(P8y);
	
			
			if(P2x>MAXX-1)
			P2x=P2x-MAXX;
			if(P2y<0)
			P2y=P2y+MAXX;
		    
			
			if(P3x>MAXX-1)
			P3x=P3x-MAXX;
			if(P3y<0)
			P3y=P3y+MAXX;
			
			if(P4x>MAXX-1)
			P4x=P4x-MAXX;
			
			
			
			if(P5x>MAXX-1)
			P5x=P5x-MAXX;
			if(P5y>MAXX-1)
			P5y=P5y-MAXX;
			
		
			
		    if(P6x>MAXX-1)
			P6x=P6x-MAXX;
			if(P6y>MAXX-1)
			P6y=P6y-MAXX;
			
			if(P7x>MAXX-1)
			P7x=P7x-MAXX;
			if(P7y>MAXX-1)
			P7y=P7y-MAXX;
			
			
			if(P8y>MAXX-1)
			P8y=P8y-MAXX;
			
				
			if (config[(int)P2x][(int)P2y]==1 && config[(int)P3x][(int)P3y]==1 && config[(int)P4x][(int)P4y]==1 && config[(int)P5x][(int)P5y]==1 && config[(int)P6x][(int)P6y]&& config[(int)P7x][(int)P7y]&& config[(int)P8x][(int)P8y]==1){ //confirm that if each square element is black or not
				
			Octagon[R]++;
			      }
			  }

			}		
		}
		cout<<Octagon[R]<<"***"<<endl;
	}
	
  }
}





int main(){

	
  double S2[Nt];  
  double ST2[Nt]; 
  double SQF[Nt];
  double TriVerF[Nt];
  double TriHorF[Nt];
  double HexaVerF[Nt];
  double HexaHorF[Nt];
  double OctagonF[Nt];
  
 

  double L[Nt];
  double LT[Nt];  

  int SS2[Nt]; // sumation of S2
  int SL[Nt];

  for(int round=1;round<=PicNum;round++){
  for(int i=0; i<Nt; i++)
    {
      S2[i] = 0;
      ST2[i] = 0;
      SS2[i] = 0;

      L[i] = 0;
      LT[i] = 0;
      SL[i] = 0;
    }

  for(int i=0; i<MAXX; i++)
    for(int j=0; j<Nt; j++)
      {
	lineS2[i][j] = 0;
	columeS2[i][j] = 0;

	N2H[i][j] = 0;
	N2V[i][j] = 0;
      }

	// we initilize all the parameters.


	string MConBasename="Mconfig.txt";//"Mconfig.txt"
    int RowN; // Used for teminating the while loop
    string MconFilename;
    
    MconFilename="";
	int num=round;


	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		MconFilename=digit+MconFilename;
		num/=10;
	         } 
    
      MconFilename+=MConBasename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////



	  for(int i=0; i<MAXX; i++)
    for(int j=0; j<MAXX; j++)
      config[i][j] = 0;


  ifstream Input(MconFilename.data());

  cout<<MconFilename<<endl;

  if (!Input.is_open()){
  cout<<"The input file doesn't exist"<<MconFilename<<endl;

  }

  NP=0;
  int tempx=0;
  int tempy=0;

  Input>>NP;

  int temp_NP = 0;

  for(int i=0; i<NP; i++)
    {

	  Input>>tempx;
	  Input>>tempy;
	  /////////////////////////////////////
	  //Change it IAW with selected scope//
	  /////////////////////////////////////
	  tempx=tempx-42;   // modify these 2 vaules IAW your sepecific scope.
	  tempy=tempy-136;  // modify these 2 vaules IAW your sepecific scope.

      if(tempx<MAXX && tempy<MAXX)   
	{
	  config[tempx][tempy] = 1;  // assign the value of black pix =1. Matrix pix=0.

	  temp_NP++;
	}
    }


  NP = temp_NP;                     
  cout<<"NP = "<<NP<<endl;
  
  //**************************************************
  //now we sample S2 for the first time...

  cout<<"sampling S_2 now..."<<endl;


   for(int i=0; i<MAXX; i++)
	{
	  sampleS2line(i);
	  sampleS2colume(i);


     for(int r=0; r<Nt; r++)
       {
	    SS2[r] = SS2[r] + lineS2[i][r] + columeS2[i][r];
	   }
    }

 for(int r=0; r<Nt; r++)
    {
      S2[r] = (double) SS2[r]/(double)(2*MAXX*MAXX); 

      printf("%d\t%f\n", r, S2[r]);
    }

  printf("**********************************************\n");



  //now we sample L for the first time...
  cout<<"sampling L now..."<<endl;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////// solve the sample_horizontal(i) and sample_vertical(i) for each Nt with another for loop/////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 

  for(int r=0; r<Nt; r++) 
    {                     
      for(int i=0; i<MAXX; i++)
	{
	  sample_horizontal(i); //slove the accumulated N2H of Nt for each row .N2H[maxx][Nt]=N2H[3][10] means that each Nt<=10 of 3rd row is stored in this matrix. 
	  sample_vertical(i);  //solve the accumulated N2V of Nt for each column..N2V[maxx][Nt]=N2V[5][10] means that each Nt<=10 of 5th row is stored in this matrix. 

	  SL[r] = SL[r] + N2H[i][r] + N2V[i][r];  // Just use for-loop to accumulate L of each horizental and vertical for specific NT(desired length)
	}

      L[r] = (double) SL[r]/(double)(2*MAXX*MAXX);

      printf("%d\t%f\n", r, L[r]);

    



    printf("**********************************************\n");
  
  
   cout<<"sampling SQ now..."<<endl;   
   
 
  double total=0;
  //double SQF[Nt];
  
  
  // initial the value
  
   for(int i=0; i<Nt; i++)
    {
      SQ[i] = 0;
      SQF[i]=0;
    }


  // calculate the # of the square range
  
  squrefunction();

 for(int r=0; r<Nt; r++)
    {
      SQF[r] = SQ[r] /(double)(MAXX*MAXX); 

      printf("%d\t%f\n", r, SQF[r]);
    }

  printf("**********************************************\n");

  printf("******************************************\n");
 
  cout<<"sampling Triangle-Vertical function now..."<<endl;
   
   
  
  // initial the value
  
   for(int i=0; i<Nt; i++)
    {
      TriVer[i] = 0;
      TriVerF[i]=0;
    }

  // calculate the # of the triangle(Vertical) range
  
  TriangleVer();
 
 
 for(int r=0; r<Nt; r++)
    {
      TriVerF[r] = TriVer[r] /(double)(MAXX*MAXX); 

      printf("%d\t%f\n", r, TriVerF[r]);
    }

  printf("**********************************************\n");

  printf("******************************************\n");

  cout<<"sampling Triangle-Horizontal function now..."<<endl;
   

  // initial the value
  
   for(int i=0; i<Nt; i++)
    {
      TriHor[i] = 0;
      TriHorF[i]=0;
    }


  // calculate the # of the triangle(horizon) range
  
  TriangleHor();
 
 
 for(int r=0; r<Nt; r++)
    {
      TriHorF[r] = TriHor[r] /(double)(MAXX*MAXX); 

      printf("%d\t%f\n", r, TriHorF[r]);
    }

  printf("**********************************************\n");

  printf("******************************************\n");

cout<<"sampling vertical Hexagon function now..."<<endl;
   

  // initial the value
  
   for(int i=0; i<Nt; i++)
    {
      HexaVer[i] = 0;
      HexaVerF[i]=0;
    }
  // calculate the # of the hexagon(vertical) range
  
  HexagonVer();


 for(int r=0; r<Nt; r++)
    {
      HexaVerF[r] = HexaVer[r] /(double)(MAXX*MAXX); 

      printf("%d\t%f\n", r, HexaVerF[r]);
    }

  printf("**********************************************\n");

  printf("******************************************\n");
  
  
    cout<<"sampling Octagon function now..."<<endl;
   
  // initial the value
  
   for(int i=0; i<Nt; i++)
    {
      Octagon[i] = 0;
    
    }
  // calculate the # of the hexagon(vertical) range
  
  Octa();
 

 for(int r=0; r<Nt; r++)
    {
      OctagonF[r] = Octagon[r] /(double)(MAXX*MAXX); 

      printf("%d\t%f\n", r, OctagonF[r]);
    }

  printf("**********************************************\n");

  
}


// Filing out for S2
num=round;

	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string S2Basename="TargetS2.txt";
    
    string S2Filename;
    
    S2Filename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		S2Filename=digit+S2Filename;
		num/=10;
	         } 
    
      S2Filename+=S2Basename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	  




  ofstream S2f(S2Filename.data());

  for(int r=0; r<Nt; r++)
    {
        S2f<< r <<" " << S2[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }

// Filing out for P4
  num=round;
  	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P4Basename="TargetP4.txt";
    
    string P4Filename;
    
    P4Filename="";

	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P4Filename=digit+P4Filename;
		num/=10;
	         } 
    
      P4Filename+=P4Basename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	

   ofstream P4f(P4Filename.data());

  for(int r=0; r<Nt; r++)
    {
        P4f<< r <<" " << SQF[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }


// Filing out for L
  num=round;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string L_Basename="TargetL.txt";
    
    string L_Filename;
    
    L_Filename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		L_Filename=digit+L_Filename;
		num/=10;
	         } 
    
      L_Filename+=L_Basename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	
  	 ofstream Lf(L_Filename.data());

     for(int r=0; r<Nt; r++){
       
        Lf<< r <<" " << L[r]<<endl;  
        }


// Filing out for P3V
num=round;
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P3VBasename="TargetP3V.txt";
    
    string P3VFilename;
    
    P3VFilename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P3VFilename=digit+P3VFilename;
		num/=10;
	         } 
    
      P3VFilename+=P3VBasename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	

 
     ofstream P3V(P3VFilename.data());

  for(int r=0; r<Nt; r++)
    {
        P3V<< r <<" " << TriVerF[r]<<endl;  
    }



// Filing out for P3H
  num=round;

  	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P3HBasename="TargetP3H.txt";
    
    string P3HFilename;
    
    P3HFilename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P3HFilename=digit+P3HFilename;
		num/=10;
	         } 
    
      P3HFilename+=P3HBasename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	

        ofstream P3H(P3HFilename.data());

  for(int r=0; r<Nt; r++)
    {
        P3H<< r <<" " << TriHorF[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }



// Filing out for P6H
  num=round;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P6HBasename="TargetP6H.txt";
    
    string P6HFilename;
    
    P6HFilename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P6HFilename=digit+P6HFilename;
		num/=10;
	         } 
    
      P6HFilename+=P6HBasename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	


     ofstream P6H(P6HFilename.data());

  for(int r=0; r<Nt; r++)
    {
        P6H<< r <<" " << HexaHorF[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }


// Filing out for P6V
  num=round;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P6VBasename="TargetP6V.txt";
    
    string P6VFilename;
    
    P6VFilename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P6VFilename=digit+P6VFilename;
		num/=10;
	         } 
    
      P6VFilename+=P6VBasename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	
    
      ofstream P6V(P6VFilename.data());

  for(int r=0; r<Nt; r++)
    {
        P6V<< r <<" " << HexaVerF[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }



// Filing out for P8
  num=round;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////

	string P8Basename="TargetP8.txt";
    
    string P8Filename;
    
    P8Filename="";



	// Adding the # in front of file.....
	while(num>0){
		char digit=(num%10)+'0';
		P8Filename=digit+P8Filename;
		num/=10;
	         } 
    
      P8Filename+=P8Basename;
      /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////
	  /////////////////////////////////////////////////////	
     ofstream P8(P8Filename.data());

  for(int r=0; r<Nt; r++)
    {
        P8<< r <<" " <<  OctagonF[r]<<endl;  // collect all the r and S2[r] data and print all the data into TS2.xls file.
    }




  } //End of for loop of calculation for different Pn files such as 1TargetS2.txt, 2TargetS2.txt ...........

  

return 0;

	cout<<" ##########"<<endl;
	

}
