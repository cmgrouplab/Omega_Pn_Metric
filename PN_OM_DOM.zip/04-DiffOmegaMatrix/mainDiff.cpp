#include <stdio.h>  //C library to perform Input/Output operations  fopen
#include <stdlib.h> //C Standard General Utilities Library
#include <math.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <string>

using namespace std;

#define MAXX 200 // **The area of interest. this has to be an even number !!! since the MAX value of Nt = MAXX/2  
#define MAXY 25000 // The whole area.
#define Nt 100 // The desired distance to solve the S2. S2(x1.x2)=s2(r). Nt=r.
#define PI acos(-1)
#define PicNum 5

void inputfile(string aa, string bb);
void TransferData(string Pntxt);
void OMEGACALCULATION(float*,float*);
void FinilizedCalculation(string AA,string AAtxt);

float O2[Nt][PicNum];
float O3[Nt][PicNum];
float O4[Nt][PicNum];
float O6[Nt][PicNum];
float O8[Nt][PicNum];
float OL[Nt][PicNum];

float matrix[Nt][PicNum];
float Calculation0[Nt][PicNum];
float Calculation[PicNum];
float ResultO2[PicNum-1];
float ResultO3[PicNum-1];
float ResultO4[PicNum-1];
float ResultO6[PicNum-1];
float ResultO8[PicNum-1];
float ResultOL[PicNum-1];


int main(){

for (int i=0;i<PicNum;i++){	
 ResultO2[i]=0;
 ResultO3[i]=0;
 ResultO4[i]=0;
 ResultO6[i]=0;
 ResultO8[i]=0;
 ResultOL[i]=0;
 }

for (int i=0;i<PicNum;i++){
 Calculation[i]=0;
 }

for (int i=0;i<Nt;i++){
	for(int j=0;j<PicNum;j++){
     Calculation0[i][j]=0;
	}
 }

     //////////////////////////////////////////
	////////////////input PN//////////////////
   //////////////////////////////////////////


  
   /////////////// input all the P2 files///////////////

    for(int i=0;i<Nt;i++){
  	  for(int j=0;j<PicNum;j++){	
  	  matrix[i][j]=0; 		
  	  }
    }
  
    string basename="TargetS2.txt";//"TargetS2.txt"
    int RowN;
    string filename;
    
    for(int i=1;i<=PicNum;i++){
    //string filename=to_string(i);
       filename="";
	int num=i;
	//cout<<"i = "<<i<<endl;

	while(num>0){
		char digit=(num%10)+'0';
		filename=digit+filename;
		num/=10;
	         } 
    
      filename+=basename;

   // cout<<"filename ="<<filename<<endl;
    
	ifstream Omega2(filename);
	

	if (!Omega2.is_open())
		cout<<"The file is not opened"<<endl;
    RowN=0;
    
    while(RowN<Nt){
          int filevalue1;
          float filevalue2;
          Omega2>>filevalue1>>filevalue2; //matrix[RowN][i-1];
          //Omega2>>matrix[RowN][i-1];
          cout<<filevalue1<<"  "<<filevalue2<<endl;
          matrix[RowN][i-1] = filevalue2;
       
          RowN=RowN+1;
           
          }
    }
  
	 ////////////////////////////////////////////////////////////////////////////////
	/////Use matrix to store all the S2 data=>>Then copy them to O2 matrix//////////
   ////////////////////////////////////////////////////////////////////////////////
 

  
   ofstream fout;
   fout.open("Omega2.txt");
  
   
   for(int i=0; i<Nt; i++){
  	for(int j=0; j<PicNum; j++)
  	{
  	  fout<<matrix[i][j]<<" ";
	  O2[i][j]=matrix[i][j];   
  	}
  	
  	fout<<endl;
      }
	
    fout.close(); 


	  //Calculate OMEGA FUNCTION

	   OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
    




	   
	for (int j=0;j<PicNum;j++){
		   float sum=0;
	    for(int i=0;i<Nt;i++){
        sum=sum+Calculation0[i][j];
	    }
		Calculation[j]=sum;
    }


	

	
	  	for(int i=0; i<PicNum; i++)
  	{
  	  cout<<Calculation[i]<<endl;

  	}
	

    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;

    for (int i=0;i<PicNum;i++)
	ResultO2[i]=Calculation[i+1];

     fout.open("Result_Diff_O2.txt");

	  	for(int i=0; i<PicNum-1; i++)
  	{
  	  cout<<ResultO2[i]<<endl;
  	  fout<<i+1<<" "<<ResultO2[i]/Nt<<endl;

  	}

       fout.close();

	   
    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;

// For Omega 3

inputfile("TargetP3V.txt", "Omega3");
TransferData("Omega3.txt");
OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
FinilizedCalculation("ResultO3","ResultO3.txt");

    for (int i=0;i<PicNum;i++)
	ResultO3[i]=Calculation[i+1];
     fout.open("Result_Diff_O3.txt");
	  	for(int i=0; i<PicNum-1; i++){
  	  	cout<<ResultO3[i]<<endl;
  	    fout<<i+1<<" "<<ResultO3[i]/Nt<<endl;
  	    }
       fout.close();


// For Omega 4

inputfile("TargetP4.txt", "Omega4");
TransferData("Omega4.txt");
OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
FinilizedCalculation("ResultO4","ResultO4.txt");

    for (int i=0;i<PicNum;i++)
	ResultO4[i]=Calculation[i+1];
     fout.open("Result_Diff_O4.txt");
	  	for(int i=0; i<PicNum-1; i++){
  	  	cout<<ResultO4[i]<<endl;
  	    fout<<i+1<<" "<<ResultO4[i]/Nt<<endl;
  	    }
       fout.close();
	   
// For Omega 6

inputfile("TargetP6V.txt", "Omega6");
TransferData("Omega6.txt");
OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
FinilizedCalculation("ResultO6","ResultO6.txt");

    for (int i=0;i<PicNum;i++)
	ResultO6[i]=Calculation[i+1];
     fout.open("Result_Diff_O6.txt");
	  	for(int i=0; i<PicNum-1; i++){
  	  	cout<<ResultO6[i]<<endl;
  	    fout<<i+1<<" "<<ResultO6[i]/Nt<<endl;
  	    }
       fout.close();


// For Omega 8


inputfile("TargetP8.txt", "Omega8");
TransferData("Omega8.txt");
OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
FinilizedCalculation("ResultO8","ResultO8.txt");

    for (int i=0;i<PicNum;i++)
	ResultO8[i]=Calculation[i+1];
     fout.open("Result_Diff_O8.txt");
	  	for(int i=0; i<PicNum-1; i++){
  	  	cout<<ResultO8[i]<<endl;
  	    fout<<i+1<<" "<<ResultO8[i]/Nt<<endl;
  	    }
       fout.close();


	   // For Omega L


inputfile("TargetL.txt", "OmegaL");
TransferData("OmegaL.txt");
OMEGACALCULATION(&O2[0][0],&Calculation0[0][0]);  
FinilizedCalculation("ResultOL","ResultOL.txt");

    for (int i=0;i<PicNum;i++)
	ResultOL[i]=Calculation[i+1];
     fout.open("Result_Diff_OL.txt");
	  	for(int i=0; i<PicNum-1; i++){
  	  	cout<<ResultOL[i]<<endl;
  	    fout<<i+1<<" "<<ResultOL[i]/Nt<<endl;
  	    }
       fout.close();





	system("pause");

  	
  }
  


  ///////////////input all the Pn files///////////////
void inputfile(string aa, string bb){
    
	for(int i=0;i<Nt;i++){
  	  for(int j=0;j<PicNum;j++){	
  	  matrix[i][j]=0; 		
  	  }
    }
	
	string basename=aa;//"TargetS2.txt"
    int RowN;
    string filename;
    
    for(int i=1;i<=PicNum;i++){
    //string filename=to_string(i);
       filename="";
	int num=i;
	//cout<<"i = "<<i<<endl;

	while(num>0){
		char digit=(num%10)+'0';
		filename=digit+filename;
		num/=10;
	         } 
    
      filename+=basename;

   // cout<<"filename ="<<filename<<endl;
    
	ifstream bb(filename);
	

	if (!bb.is_open())
		cout<<"The file is not opened"<<endl;
    RowN=0;
    
    while(RowN<Nt){
          int filevalue1;
          float filevalue2;
          bb>>filevalue1>>filevalue2; //matrix[RowN][i-1];
          //Omega2>>matrix[RowN][i-1];
          cout<<filevalue1<<"  "<<filevalue2<<endl;
          matrix[RowN][i-1] = filevalue2;
       
          RowN=RowN+1;
           
          }
     }
}  




     ////////////////////////////////////////////////////////////////////////////
	////Use matrix to store all the Pn's data=>>Then copy them to O2 matrix/////
   ////////////////////////////////////////////////////////////////////////////
 

void TransferData(string Pntxt){  
   ofstream fout;
   fout.open(Pntxt);
  
   
   for(int i=0; i<Nt; i++){
  	for(int j=0; j<PicNum; j++)
  	{
  	  fout<<matrix[i][j]<<" ";
	  O2[i][j]=matrix[i][j];   
  	}
  	
  	fout<<endl;
      }
	
    fout.close(); 
}







    ////////////////////////////////////////////////////////////////////////
	////Use different input MATRIX to calculate Omega fonction//////////////
    ////////////////////////////////////////////////////////////////////////

  void OMEGACALCULATION(float* AA,float* BB){

	 	 for (int j=0;j<PicNum;j++){
	    for(int i=0;i<Nt;i++){
        Calculation0[i][j]=0;
	    }
    }
	 
     for (int i =0;i<Nt;i++){
          for (int j =0;j<PicNum;j++){
          //BB[i*PicNum+j]=BB[i*PicNum+j]+abs(AA[i*PicNum+j]-AA[i*PicNum]);
		  BB[i*PicNum+j]=BB[i*PicNum+j]+abs(AA[i*PicNum+j+1]-AA[i*PicNum+j]);
          }
     }

  
}


void FinilizedCalculation(string AA,string AAtxt){

  for (int j=0;j<PicNum;j++){
		   float sum=0;
	    for(int i=0;i<Nt;i++){
        sum=sum+Calculation0[i][j];
	    }
		Calculation[j]=sum;
    }

	  	for(int i=0; i<PicNum+1; i++) 
  	{
  	  cout<<Calculation[i]<<endl;

  	}
	
    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;
    cout<<"#################################################"<<endl;

}
